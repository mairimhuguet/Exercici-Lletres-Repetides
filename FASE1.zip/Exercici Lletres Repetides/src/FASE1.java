
public class FASE1 {

	public static void main(String[] args) {
		
		char [] nombre = {'m', 'i', 'r', 'i', 'a', 'm'};		
		
		for(int i = 0; i < nombre.length; i++)
		{
			System.out.println(nombre[i]+ " ");
		}
	}

}
